﻿namespace ProiectPaw
{
    partial class MeniuAplicatieForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.adaugaUnitate_button = new System.Windows.Forms.Button();
            this.database_button = new System.Windows.Forms.Button();
            this.MatObs_button = new System.Windows.Forms.Button();
            this.sondaj_button = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.inapoiButon = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(108, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(229, 24);
            this.label1.TabIndex = 0;
            this.label1.Text = "Anchetă unități agricole";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(24, 69);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(194, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Adaugă Unitate Agricolă:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(14, 109);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(209, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "Editare Unități Inregistrate:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(14, 155);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(161, 20);
            this.label4.TabIndex = 3;
            this.label4.Text = "Matrice Observatie: ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(14, 197);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(296, 20);
            this.label5.TabIndex = 4;
            this.label5.Text = "Variabile de esantionare(DE* ori judet)";
            // 
            // adaugaUnitate_button
            // 
            this.adaugaUnitate_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.adaugaUnitate_button.Location = new System.Drawing.Point(350, 66);
            this.adaugaUnitate_button.Name = "adaugaUnitate_button";
            this.adaugaUnitate_button.Size = new System.Drawing.Size(99, 23);
            this.adaugaUnitate_button.TabIndex = 5;
            this.adaugaUnitate_button.Text = "ADAUGĂ";
            this.adaugaUnitate_button.UseVisualStyleBackColor = true;
            this.adaugaUnitate_button.Click += new System.EventHandler(this.adaugaUnitate_button_Click);
            // 
            // database_button
            // 
            this.database_button.Location = new System.Drawing.Point(350, 109);
            this.database_button.Name = "database_button";
            this.database_button.Size = new System.Drawing.Size(99, 23);
            this.database_button.TabIndex = 6;
            this.database_button.Text = "EDITARE";
            this.database_button.UseVisualStyleBackColor = true;
            this.database_button.Click += new System.EventHandler(this.database_button_Click);
            // 
            // MatObs_button
            // 
            this.MatObs_button.Location = new System.Drawing.Point(350, 152);
            this.MatObs_button.Name = "MatObs_button";
            this.MatObs_button.Size = new System.Drawing.Size(99, 23);
            this.MatObs_button.TabIndex = 7;
            this.MatObs_button.Text = "VIZUALIZARE";
            this.MatObs_button.UseVisualStyleBackColor = true;
            this.MatObs_button.Click += new System.EventHandler(this.MatObs_button_Click);
            // 
            // sondaj_button
            // 
            this.sondaj_button.Location = new System.Drawing.Point(350, 194);
            this.sondaj_button.Name = "sondaj_button";
            this.sondaj_button.Size = new System.Drawing.Size(99, 23);
            this.sondaj_button.TabIndex = 8;
            this.sondaj_button.Text = "VIZUALIZARE";
            this.sondaj_button.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            this.button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.Location = new System.Drawing.Point(18, 296);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(112, 23);
            this.button5.TabIndex = 9;
            this.button5.Text = "INCHIDE";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // inapoiButon
            // 
            this.inapoiButon.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.inapoiButon.Location = new System.Drawing.Point(141, 296);
            this.inapoiButon.Name = "inapoiButon";
            this.inapoiButon.Size = new System.Drawing.Size(112, 23);
            this.inapoiButon.TabIndex = 10;
            this.inapoiButon.Text = "PAGINA START";
            this.inapoiButon.UseVisualStyleBackColor = true;
            this.inapoiButon.Click += new System.EventHandler(this.inapoiButon_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(15, 229);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(227, 16);
            this.label6.TabIndex = 11;
            this.label6.Text = "-> DE* = dimensiune economica";
            // 
            // MeniuAplicatieForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(553, 331);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.inapoiButon);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.sondaj_button);
            this.Controls.Add(this.MatObs_button);
            this.Controls.Add(this.database_button);
            this.Controls.Add(this.adaugaUnitate_button);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "MeniuAplicatieForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Meniu Principal Aplicatie";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button adaugaUnitate_button;
        private System.Windows.Forms.Button database_button;
        private System.Windows.Forms.Button MatObs_button;
        private System.Windows.Forms.Button sondaj_button;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button inapoiButon;
        private System.Windows.Forms.Label label6;
    }
}

