﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProiectPaw
{
    public partial class ModificaDateForm : Form
    {
        string Denumire;
        Adresa _Adresa = new Adresa();
        Indicatori _Indicatori = new Indicatori();
        public UnitateAgricola Rezultat = new UnitateAgricola();

        public ModificaDateForm(string denumire, Adresa adresa, Indicatori indicatori)
        {
            InitializeComponent();
            Denumire = denumire;
            _Adresa = adresa;
            _Indicatori = indicatori;

            AfisareDateCurente();
        }

        void AfisareDateCurente()
        {
            textBox1.Text = Denumire;
            textBox2.Text = _Adresa.Judet;
            textBox3.Text = _Adresa.Strada;
            textBox4.Text = _Adresa.Numar.ToString();
            textBox5.Text = _Indicatori.TerenArabil.ToString();
            textBox6.Text = _Indicatori.Vii.ToString();
            textBox7.Text = _Indicatori.Livezi.ToString();
            textBox8.Text = _Indicatori.Pasuni.ToString();
        }

        //vezi modificari - buton
        private void button2_Click(object sender, EventArgs e)
        {
            int count = 0;
            string modificari = "";

            if (textBox1.Text != Denumire)
            {
                count++;
                modificari = modificari + "Denumire: " + textBox1.Text;
            }
            if (textBox2.Text != _Adresa.Judet)
            {
                count++;
                modificari += "\nJudet: " + textBox2.Text;
            }
            if (textBox3.Text != _Adresa.Strada)
            {
                count++;
                modificari += "\nStrada: " + textBox3.Text;
            }
            if (textBox4.Text != _Adresa.Numar.ToString())
            {
                count++;
                modificari += "\nNumarul: " + textBox4.Text;
            }
            if (textBox5.Text != _Indicatori.TerenArabil.ToString())
            {
                count++;
                modificari += "\nTeren arabil (ha): " + textBox5.Text;
            }
            if (textBox6.Text != _Indicatori.Vii.ToString())
            {
                count++;
                modificari += "\nVii (ha): " + textBox6.Text;
            }
            if (textBox7.Text != _Indicatori.Livezi.ToString())
            {
                count++;
                modificari += "\nLivezi (ha): " + textBox7.Text;
            }
            if (textBox8.Text != _Indicatori.Pasuni.ToString())
            {
                count++;
                modificari += "\nPasuni (ha): " + textBox8.Text;
            }

            if(count > 0) {
                MessageBox.Show(string.Format(
                    "S-au produs {0} modificari acestea sunt: \n {1}", count.ToString(), modificari));               
            }
            else
            {
                MessageBox.Show("Nu s-au produs modificari!");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Close();
        }

       private bool DateValide()
        {
            //denumire
            string den = textBox1.Text;
            if (string.IsNullOrEmpty(den))
                return false;

            //judet
            string jud = textBox2.Text;
            if (string.IsNullOrEmpty(jud) || jud.Any(char.IsDigit))
                return false;

            //strada
            string str = textBox3.Text;
            if (string.IsNullOrEmpty(str) || str.Any(char.IsDigit))
                return false;

            //numarul
            string nr = textBox4.Text;
            if (string.IsNullOrEmpty(nr) || nr.Any(char.IsLetter))
                return false;

            //teren arabil
            string ta = textBox5.Text;
            if (string.IsNullOrEmpty(ta) || ta.Any(char.IsLetter) || double.Parse(ta) < 0)
                return false;

            //vii
            string v = textBox6.Text;
            if (string.IsNullOrEmpty(v) || v.Any(char.IsLetter) || double.Parse(v) < 0)
                return false;

            //livezi
            string l = textBox7.Text;
            if (string.IsNullOrEmpty(l) || l.Any(char.IsLetter) || double.Parse(l) < 0)
                return false;

            //pasuni
            string p = textBox8.Text;
            if (string.IsNullOrEmpty(p) || p.Any(char.IsLetter) || double.Parse(p) < 0)
                return false;
            else
                return true;
        }

        //salveaza modificari - buton
        private void button1_Click(object sender, EventArgs e)
        {
            bool legal = DateValide();
            if (!legal)
                MessageBox.Show(string.Format("Datele nu au fost introduse corect!\n"
                    + "Verificati daca exista: \n 1.Campuri goale \n 2. Numere negative pentru " +
                    "indicatorii numerici\n 3. Judetul nu poate contine numere"));
            else
            {
                DialogResult dialog = MessageBox.Show("Datele se vor modifica permanent! Sunteti sigur?", "Atentie!",
                    MessageBoxButtons.OKCancel);
                
                if(dialog == DialogResult.OK)
                {
                    MessageBox.Show(string.Format("Datele au fost modificate!"));
                    Rezultat.Denumire = textBox1.Text;
                    Rezultat._Adresa.Judet = textBox2.Text;
                    Rezultat._Adresa.Strada = textBox3.Text;
                    Rezultat._Adresa.Numar = int.Parse(textBox4.Text);
                    Rezultat._Indicatori.TerenArabil = double.Parse(textBox5.Text);
                    Rezultat._Indicatori.Vii = double.Parse(textBox6.Text);
                    Rezultat._Indicatori.Livezi = double.Parse(textBox7.Text);
                    Rezultat._Indicatori.Pasuni = double.Parse(textBox8.Text);

                    //TODO:
                        //rescrie fisierultxt ca sa se salveze datele de tot!
                }
            }
        }
    }
}
