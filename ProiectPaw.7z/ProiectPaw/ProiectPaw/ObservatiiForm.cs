﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProiectPaw
{
    public partial class ObservatiiForm : Form
    {
        public List<UnitateAgricola> Unitati = new List<UnitateAgricola>();

        public ObservatiiForm(List<UnitateAgricola> unitati)
        {
            InitializeComponent();
            Unitati = unitati;

            listView1.AllowDrop = true;
            listView1.View = View.Details;
            listView1.Columns.Add("Județ", 80);
            listView1.Columns.Add("Teren arabil (total ha): ", 120);
            listView1.Columns.Add("Vie (total ha): ", 90);
            listView1.Columns.Add("Livadă (total ha): ", 100);
            listView1.Columns.Add("Pășune (total ha): ", 100);

            AfisareMapa();
            InitPieChart();

            AllowDrop = true;
            
        }

        Dictionary<string, Indicatori> GetDate()
        {
            var myMap = new Dictionary<string, Indicatori>();

            foreach(var unitate in Unitati.OrderBy(u => u._Adresa.Judet))
            {
                if (!myMap.ContainsKey(unitate._Adresa.Judet))
                {
                    Indicatori indicatori = new Indicatori(unitate._Indicatori.TerenArabil,
                        unitate._Indicatori.Vii, unitate._Indicatori.Livezi, unitate._Indicatori.Pasuni);
                    myMap.Add(unitate._Adresa.Judet, indicatori);
                }
                else
                {
                    myMap[unitate._Adresa.Judet].TerenArabil += unitate._Indicatori.TerenArabil;
                    myMap[unitate._Adresa.Judet].Vii += unitate._Indicatori.Vii;
                    myMap[unitate._Adresa.Judet].Livezi += unitate._Indicatori.Livezi;
                    myMap[unitate._Adresa.Judet].Pasuni += unitate._Indicatori.Pasuni;
                }
            }

            return myMap;
        }

        void AfisareMapa()
        {
            listView1.Items.Clear();
            var DateMap = GetDate();

            foreach(var unitate in DateMap)
            {
                ListViewItem item = new ListViewItem();
                item.Text = unitate.Key;
                item.SubItems.Add(unitate.Value.TerenArabil.ToString("0.00"));
                item.SubItems.Add(unitate.Value.Vii.ToString("0.00"));
                item.SubItems.Add(unitate.Value.Livezi.ToString("0.00"));
                item.SubItems.Add(unitate.Value.Pasuni.ToString("0.00"));

                listView1.Items.Add(item);
            }
        }

        private void GetTotalHa(out double terenA, out double vii, out double livezi, out double pasuni)
        {
            terenA = 0;
            vii = 0;
            livezi = 0;
            pasuni = 0;

            foreach(var unitate in Unitati)
            {
                terenA += unitate._Indicatori.TerenArabil;
                vii += unitate._Indicatori.Vii;
                livezi += unitate._Indicatori.Livezi;
                pasuni += unitate._Indicatori.Pasuni;
            }
        }

        void InitPieChart()
        {
            chart1.Titles.Add("Repartizare");
            chart1.Series["totalhaSeries"].IsValueShownAsLabel = true;
            chart1.Series["totalhaSeries"].Font = new Font("Times", 12f);

            double ta = 0, v = 0, l = 0, p = 0;
            GetTotalHa(out ta, out v, out l, out p);
            chart1.Series["totalhaSeries"].Points.AddXY("TerenArabil", ta);
            chart1.Series["totalhaSeries"].Points.AddXY("Vii", v);
            chart1.Series["totalhaSeries"].Points.AddXY("Livezi", l);
            chart1.Series["totalhaSeries"].Points.AddXY("Pășuni: ", p);

        }

        private void inchideToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        //list view MOUSE DOWN DELEGATE
        private void ListView_DragDrop(object sender, MouseEventArgs e)
        {            
            //if (listView1.SelectedItems.Count > 0)
            //{
            //    listView1.DoDragDrop(listView1.SelectedItems.ToString(), DragDropEffects.Copy);
            //}
        }

        //textbox DRAG ENTER
        private void TextBoxDragEnter(object sender, DragEventArgs e)
        {
            //if (e.Data.GetDataPresent(DataFormats.Text))
            //    e.Effect = DragDropEffects.Copy;
            //else
            //    e.Effect = DragDropEffects.None;
        }

        //textbox DRAG DROP
        private void TextBoxDragDrop(object sender, DragEventArgs e)
        {
            //judetDraggedTxtBox.Text = e.Data.GetData(DataFormats.StringFormat).ToString();
        }

        private void ListViewSelected_Mouse_Click(object sender, MouseEventArgs e)
        {
            listView1.Focus();
            listView1.FullRowSelect = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            chart1.Printing.PrintPreview();
        }
    }
}
