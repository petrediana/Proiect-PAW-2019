﻿namespace ProiectPaw
{
    partial class VizualizareUnitatiForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listView1 = new System.Windows.Forms.ListView();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.cautaDupaCUIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.codulDeCautareToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.CUItextBox = new System.Windows.Forms.ToolStripTextBox();
            this.toateUnitatiileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.inchideToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // listView1
            // 
            this.listView1.Location = new System.Drawing.Point(25, 27);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(121, 97);
            this.listView1.TabIndex = 0;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.ItemSelectionChanged += new System.Windows.Forms.ListViewItemSelectionChangedEventHandler(this.Select_unitatiLV);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cautaDupaCUIToolStripMenuItem,
            this.inchideToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(899, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // cautaDupaCUIToolStripMenuItem
            // 
            this.cautaDupaCUIToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.codulDeCautareToolStripMenuItem,
            this.toateUnitatiileToolStripMenuItem});
            this.cautaDupaCUIToolStripMenuItem.Name = "cautaDupaCUIToolStripMenuItem";
            this.cautaDupaCUIToolStripMenuItem.Size = new System.Drawing.Size(105, 20);
            this.cautaDupaCUIToolStripMenuItem.Text = "Cauta dupa CUI:";
            // 
            // codulDeCautareToolStripMenuItem
            // 
            this.codulDeCautareToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.CUItextBox});
            this.codulDeCautareToolStripMenuItem.Name = "codulDeCautareToolStripMenuItem";
            this.codulDeCautareToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.codulDeCautareToolStripMenuItem.Text = "Codul de cautare ->";
            // 
            // CUItextBox
            // 
            this.CUItextBox.Name = "CUItextBox";
            this.CUItextBox.Size = new System.Drawing.Size(100, 23);
            this.CUItextBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Enter_cautaCUI);
            // 
            // toateUnitatiileToolStripMenuItem
            // 
            this.toateUnitatiileToolStripMenuItem.Name = "toateUnitatiileToolStripMenuItem";
            this.toateUnitatiileToolStripMenuItem.Size = new System.Drawing.Size(202, 22);
            this.toateUnitatiileToolStripMenuItem.Text = "Toate unitatiile \\ Refresh";
            this.toateUnitatiileToolStripMenuItem.Click += new System.EventHandler(this.toateUnitatiileToolStripMenuItem_Click);
            // 
            // inchideToolStripMenuItem
            // 
            this.inchideToolStripMenuItem.Name = "inchideToolStripMenuItem";
            this.inchideToolStripMenuItem.Size = new System.Drawing.Size(58, 20);
            this.inchideToolStripMenuItem.Text = "Inchide";
            this.inchideToolStripMenuItem.Click += new System.EventHandler(this.inchideToolStripMenuItem_Click);
            // 
            // VizualizareUnitatiForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(899, 280);
            this.Controls.Add(this.listView1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "VizualizareUnitatiForm";
            this.Text = "VizualizareUnitati";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem cautaDupaCUIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem codulDeCautareToolStripMenuItem;
        private System.Windows.Forms.ToolStripTextBox CUItextBox;
        private System.Windows.Forms.ToolStripMenuItem toateUnitatiileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem inchideToolStripMenuItem;
    }
}